package base;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
//import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import utilities.WebDriverInstance;

public class Setup_web {

	// public static final String PROPERTY_PATH = "src\\test\\java\\properties\\configuration.property";

	public static WebDriver driver = null;

	
	@BeforeSuite
	public static void Basic_WebdriverSetup() throws Exception {

			WebDriverInstance DriverInst = new WebDriverInstance();
			DriverInst.execute();
			driver = DriverInst.getDriver();
			}

	/**
	 *After Suite
	 */
	@AfterSuite
	public static void afterClass() {
		driver.quit();
	}
}
