package utilities;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;



public class WebDriverInstance {	
	 String baseURL ="https://dailyburn.com";
	
	  public WebDriver driver = null;
	
	     
      /**
      * @return the driver
      */
      public WebDriver getDriver() {
                      return driver;
      }
      /**
      * @param args
     * @throws InterruptedException 
      *
     
       *
       */
      public void execute() throws InterruptedException {
                      driver = Web_ManageBrowser.setBrowser();
                      driver.get(baseURL);
                      driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
                                        
      }
}

 	


