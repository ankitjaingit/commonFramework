package utilities;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.Setup_web;


public class Utilities_Web extends Setup_web
{
	public static WebElement obj_ele = null;

	// Function written to read details from properties file
	public Properties readProp(String strpath) throws IOException 
	{
		System.out.println("PATH :"+strpath);
		System.out.println("Driver Path: "+System.getProperty("user.dir"));
		//System.out.println("PATH is: "+System.getProperty("user.dir")+ path);
		File LoginFile =new File(System.getProperty("user.dir")+ strpath);
		Properties properties = new Properties();
		FileReader LoginReader = new FileReader(LoginFile);
		properties.load(LoginReader);  

		return properties;
	}



//	public WebElement searchElement(WebDriver driver,String identifier, String value)
//	{
//		WebElement obj_ele=null; 
//		switch (identifier)
//		{
//		case "id":
//			obj_ele = driver.findElement(By.id(value));
//			break;
//
//		case"className":
//			obj_ele = driver.findElement(By.className(value));
//			break;
//
//		case"xpath":
//			obj_ele = driver.findElement(By.xpath(value));
//			break;	
//
//		case"tagName":
//			obj_ele = driver.findElement(By.tagName(value));
//			break;
//		default:
//			System.out.println("test is not working");
//		}
//		return obj_ele;
//
//	}


	public static WebElement isClickable(String identifier, String value) throws IOException
	{
		WebDriverWait wait = new WebDriverWait(driver, 2000);
		switch(identifier)
		{
		case "id":
			wait.until(ExpectedConditions.elementToBeClickable(By.id(value)));
			obj_ele =driver.findElement(By.id(value));;
			break;
		case "className":
			wait.until(ExpectedConditions.elementToBeClickable(By.className(value)));
			obj_ele =driver.findElement(By.className(value));
			break;
		case "xpath":
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(value)));
			obj_ele =driver.findElement(By.xpath(value));
			break;	
		case "tagName":
			wait.until(ExpectedConditions.elementToBeClickable(By.tagName(value)));
			obj_ele =driver.findElement(By.tagName(value));
			break;	
		default:
			System.out.println("test is not working");
		}
		return obj_ele;
	}

	
//	public WebElement WaitToVisible(String identifier, String value)
//	{
//		WebDriverWait wait = new WebDriverWait(driver, 1000);
//		switch (identifier)
//		{
//		case "id":
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(value)));
//			obj_ele =driver.findElement(By.id(value));;
//			break;
//		case "className":
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(value)));
//			obj_ele =driver.findElement(By.className(value));
//			break;
//		case "xpath":
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(value)));
//			obj_ele =driver.findElement(By.xpath(value));
//			break;	
//		case "tagName":
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName(value)));
//			obj_ele =driver.findElement(By.tagName(value));
//			break;	
//		
//		default:
//			System.out.println("test is not working");
//		}
//		return obj_ele;
//	}
//
//
//	public void UntilTextEqual(String text)
//	{
//		WebDriverWait wait = new WebDriverWait(driver, 1000);
//		wait.until(ExpectedConditions.urlToBe(text));
//
//	}
//
//
//	public boolean elementBecomesInvisible(String identifier, String value)
//	{
//		boolean isVisible = false;
//		WebDriverWait wait = new WebDriverWait(driver, 1000);
//		switch (identifier)
//		{
//		case "id":
//			isVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(value)));
//
//			break;
//
//		case"className":
//			isVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className(value)));
//			break;
//
//		case"xpath":
//			isVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(value)));
//			break;
//		default:
//			System.out.println("test is not working");
//
//		}
//		return isVisible;
//	}


}


