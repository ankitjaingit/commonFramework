package utilities;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Web_ManageBrowser {

	public static String Selected_Browser;


	public static WebDriver setBrowser() {

		WebDriver driver= null;

		Utilities_Web  CmnUtil = new Utilities_Web();

		try {
			
			Selected_Browser = CmnUtil.readProp("/src/main/java/globalproperty/global_Web.properties").getProperty("Intend_Browser");

			if (Selected_Browser.equalsIgnoreCase("chrome")!= false)

			{
				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/src/main/java/resources/chromedriver");
				driver = new  ChromeDriver();
				//driver.get("https://dailyburn.com");
				driver.manage().window().maximize();

			}
			else if (Selected_Browser.equalsIgnoreCase("firefox")!= false)
			{
				System.setProperty("webdriver.firefox.driver",System.getProperty("user.dir")+"/src/main/java/resources/firefoxdriver/geckodriver-v0.23.0-macos.tar");
				driver = new  FirefoxDriver();
				driver.manage().window().maximize();

			}
			else 
			{
				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/src/main/java/resources/chromedriver");
				driver = new  ChromeDriver();
				driver.manage().window().maximize();
				//driver.get("www.google.com");
			}
		}

		catch (IOException e) 
		{ 
			e.printStackTrace();
		}
		return driver;

	}

}
