package objectrepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class HomePage_IOS {

	// 1. Is to call the driver object from testcase to Pageobject file

	//Concatenate driver
	public HomePage_IOS(IOSDriver<IOSElement> Appdriver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(Appdriver), this);

	}




    @iOSXCUITFindBy(xpath="//XCUIElementTypeApplication[@name=\\\"UICatalog\\\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[3])")
	private IOSElement ActionSheet;

	
	
	public WebElement getActionSheet()
	{
		System.out.println("trying to click on action sheet field");
		return ActionSheet;
	}



    @iOSXCUITFindBy(xpath="//XCUIElementTypeApplication[@name=\"UICatalog\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[4]")
	private IOSElement ButtonsField;
	
	public WebElement getButtonsfield()
	{
		System.out.println("trying to click on Button field");
		return ButtonsField;
	}

	
	
	
	
	
//	MobileElement el3 = (MobileElement) driver.findElementByAccessibilityId("X Button");
//	el3.click();

	
//	@AndroidFindBy(id="com.androidsample.generalstore:id/nameField")
//	private WebElement nameField;
//	
//	public WebElement getNameField()
//	{
//		System.out.println("trying to find the Name field");
//		return nameField;
//	}
//	//call this in test as below
//	FormPage formPage=new FormPage(driver);
//	formPage.getNameField().sendKeys("hello");
	









}
