package DB_IOS_Tests;

import java.io.IOException;

import org.testng.annotations.*;

import base.base_IOS;


public class ClearNode extends base_IOS {
	//public static AppiumDriverLocalService service;
	@BeforeSuite
	public void StartNode() throws IOException {
		
		System.out.println("Inside BeforeTest");
		String[] command = { "/usr/bin/killall", "-KILL","node" };
		Runtime.getRuntime().exec(command);
		//service=startServer();
		System.out.println("Command executed");
		
	}

}
