package DB_Web_Tests;
import java.io.IOException;

import base.Setup_web;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import objectrepository.GlobalObjects;
import utilities.Utilities_Web;


public class SignIn extends Utilities_Web
{
	public static WebElement SignInBTN, UserName, Password, LogIn, LastLoadedObject;
	public String AfterLoginURL;


    @Test
	public static void signIntoApplication() throws IOException, InterruptedException
	{
        Setup_web test = new Setup_web();
	    SignInBTN= isClickable(GlobalObjects.SIGNIN, GlobalObjects.SIGNINBTN_VAL);
	
		SignInBTN.click();
		Thread.sleep(5000);
		System.out.println("Here we go");
		test.afterClass();
	}


}
